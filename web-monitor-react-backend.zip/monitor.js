const fs = require('fs');
const axios = require('axios');
const cheerio = require('cheerio');
const slugify = require('slugify');
const { diffLines } = require('diff');

async function fetchHTML(url) {
  const res = await axios.get(url);
  return res.data;
}

function compare(oldHtml, newHtml) {
  const diffs = diffLines(oldHtml, newHtml);
  return diffs.filter(line => line.added || line.removed);
}

async function processURL(url) {
  const html = await fetchHTML(url);
  const folder = slugify(url);
  const path = `./data/${folder}.html`;
  let oldHtml = '';

  if (fs.existsSync(path)) {
    oldHtml = fs.readFileSync(path, 'utf-8');
  }

  const changes = compare(oldHtml, html);
  fs.writeFileSync(path, html);

  return { url, changed: changes.length > 0, changes };
}

(async () => {
  const urls = fs.readFileSync('urls.txt', 'utf-8').split('\n').filter(Boolean);
  const results = [];

  for (const url of urls) {
    const res = await processURL(url);
    results.push(res);
  }

  fs.writeFileSync('resultados.json', JSON.stringify(results, null, 2));
})();
